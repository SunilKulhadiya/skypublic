import React, {useState, Component } from 'react';

const Base=() =>{
const BASEURL = 'https://skygroupofeducation.com/school/';
}
export { Base };
