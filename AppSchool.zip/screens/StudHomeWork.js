import React from "react";
import { View, StyleSheet, Text, Image, Dimensions, useWindowDimensions, ScrollView, ActivityIndicator, 
        TouchableOpacity, FlatList, RefreshControl } from "react-native";
import { FontAwesome } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';   
//import { TabView, SceneMap } from 'react-native-tab-view';        //npm i react-native-tab-view
//npm install @react-native-community/masked-view react-native-select-dropdown
import SelectDropdown from "react-native-select-dropdown";

import { Base } from "../screens/Base";

const DEVICEWIDTH = Dimensions.get('window').width;
const DEVICEHEIGHT = Dimensions.get('window').height;


const StudHomeWork = ({navigation, route}) => {

    const Subjects = [{section: "All Subjects", id: '0'}, {section: "Hindi", id: '1'}, {section: "English", id: '2'},
                            {section: "Mathe", id: '3'}, {section: "Sanskrit", id: '4'}, {section: "Science", id: '5'},
                            {section: "Social Science", id: '6'}, {section: "EVS", id: '7'}, {section: "Geography", id: '8'},
                            {section: "Biology", id: '9'}, {section: "Commerce", id: '10'}, {section: "GK", id: '11'}];
    const [SelectedSubject, set_Subject] = React.useState('All Subjects');
    const [DataS, set_data] = React.useState([]);
    const [isLoading, reset_isLoading]=React.useState(true);

    const [SelectPending, set_Pending] = React.useState(true);
    const [SelectSubmit, set_Submit] = React.useState(false);
    const [SelectEvaluate, set_Evaluate] = React.useState(false);
    const [StdID, set_StdID] = React.useState('');
    const [refreshing, setRefreshing] = React.useState(false);
    const [color, changeColor] = React.useState('red');
    const [chevrondownSection, setchevrondownSection] = React.useState(true);
    const [SectionLView, set_SectionLView] = React.useState("none");
    const [FlatListRefresh, set_FlatListRefresh] = React.useState(true);

    const FetchPersonal=()=>{
         console.log("Home, Std ID :", Base.BASEURL);
        console.log("Home, Std ID :", StdID);
      reset_isLoading(true);
        AsyncStorage.getItem('StdID').then((stdID) => {
            AsyncStorage.getItem('SERVERURL').then(async (SBASEURL) => {
                console.log("Home, Std ID :", SBASEURL);
                console.log("Home, Std ID :", stdID);

                try{
                    let respons1 = await fetch(SBASEURL+'api/Webservice/getHomework', {
                      method: 'POST', headers: {'Accept': 'application/json', 'Content-Type': 'application/json',},
                      body: JSON.stringify({student_id: stdID})
                    });
                    let responsJson = await respons1.json();
                    set_data(responsJson);
                    console.log("DataS :", responsJson);
                    console.log("DataS :",(DataS.length));
                    reset_isLoading(false);

                }catch(err){
                    console.error("Error-2 : ",err);
                }

            });
        });
    }
    React.useEffect(() => {
        if(StdID == '')
            AsyncStorage.getItem('StdID').then((value) => set_StdID(value));
        FetchPersonal()
    }, []);

      const [index, setIndex] = React.useState(0);

      const [routes] = React.useState([
        { key: 'first', title: 'PERSONAL' },
        { key: 'second', title: 'PARENTS' },
        { key: 'third', title: 'OTHER' },
      ]);

      function ChoosePending(){
        set_Pending(true);
        set_Submit(false);
        set_Evaluate(false);
      }
      function ChooseSubmite(){
        set_Pending(false);
        set_Submit(true);
        set_Evaluate(false);
      }
      function ChooseEvaluate(){
        set_Pending(false);
        set_Submit(false);
        set_Evaluate(true);
      }

    const onRefresh = () => {
        setRefreshing(true);
        changeColor('red');
        FetchPersonal();
        setTimeout(() => {
        changeColor('green');
        setRefreshing(false);
        }, 2000);
    };

    const ShowList = (Itm, Index) => {
        console.log("ShowList, SelectedSubject : ", SelectedSubject);
        if(Itm.name == SelectedSubject || SelectedSubject == "All Subjects"){
            return(
            <View style={styles.SContainer}>
                <View style={styles.CardView2}>
                <View style={{width: DEVICEWIDTH * 0.95, height: DEVICEHEIGHT * 0.05, backgroundColor: "#BAFAFF",
                                borderTopLeftRadius: 15, borderTopRightRadius: 15, justifyContent: "center"}}>
                    <Text style={{color: "#000000", marginLeft: 10, fontWeight: "bold"}}>{Itm.name}</Text>
                </View>
                <View style={styles.Column2}>
                    <View style={styles.Row2}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000"}}>Homework Dt.</Text>
                        <Text style={{width: DEVICEWIDTH * 0.1, color: "#000000"}}>:</Text>
                        <Text style={{width: DEVICEWIDTH * 0.4, fontWeight: "700"}}>{Itm.homework_date}</Text>
                    </View>
                    <View style={styles.Row2}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000"}}>Submission Dt.</Text>
                        <Text style={{width: DEVICEWIDTH * 0.1, color: "#000000"}}>:</Text>
                        <Text style={{width: DEVICEWIDTH * 0.4, fontWeight: "700"}}>{Itm.submit_date}</Text>
                    </View>
                    <View style={styles.Row2}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000"}}>Created By</Text>
                        <Text style={{width: DEVICEWIDTH * 0.1, color: "#000000"}}>:</Text>
                        <Text style={{width: DEVICEWIDTH * 0.4, fontWeight: "700"}}>{Itm.created_by}</Text>
                    </View>
                    <View style={styles.Row2}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000"}}>Evaluated By</Text>
                        <Text style={{width: DEVICEWIDTH * 0.1, color: "#000000"}}>:</Text>
                        <Text style={{width: DEVICEWIDTH * 0.4, fontWeight: "700"}}>{Itm.evaluated_by}</Text>
                    </View>
                    <View style={styles.Row2}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000"}}>Evaluation Dt.</Text>
                        <Text style={{width: DEVICEWIDTH * 0.1, color: "#000000"}}>:</Text>
                        <Text style={{width: DEVICEWIDTH * 0.4, fontWeight: "700"}}>{Itm.evaluation_date}</Text>
                    </View>
                    <View style={styles.Row2}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000"}}>Marks</Text>
                        <Text style={{width: DEVICEWIDTH * 0.1, color: "#000000"}}>:</Text>
                        <Text style={{width: DEVICEWIDTH * 0.4, fontWeight: "700"}}>35</Text>
                    </View>
                    <View style={styles.Row2}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000"}}>Marks Obtained</Text>
                        <Text style={{width: DEVICEWIDTH * 0.1, color: "#000000"}}>:</Text>
                        <Text style={{width: DEVICEWIDTH * 0.4, fontWeight: "700"}}>34</Text>
                    </View>
                    <View style={styles.Row2}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000"}}>Note</Text>
                        <Text style={{width: DEVICEWIDTH * 0.1, color: "#000000"}}>:</Text>
                        <Text style={{width: DEVICEWIDTH * 0.4, fontWeight: "700"}}></Text>
                    </View>
                </View>
                <View style={{flexDirection: "row", marginTop: 20, marginLeft: 10}}>
                        <Text style={{width: DEVICEWIDTH * 0.4, color: "#000000",}}>
                            Description</Text>
                </View>
                    <Text style={{width: DEVICEWIDTH * 0.7, fontWeight: "700", marginLeft: 10}}>
                        {Itm.description}</Text>
                <View style={{marginTop: 15}}></View>
                </View>
            </View>
            );
        }
    }

    const SubjectFilter = () =>{
        setchevrondownSection(!chevrondownSection);

        if(chevrondownSection){
            set_SectionLView("flex");
        }else{
            set_SectionLView("none");
        }
    }
    const SelectSubject = async (idd, SectionTitle) => {
        set_Subject(SectionTitle);
        set_SectionLView("none");
        setchevrondownSection(true);
        set_FlatListRefresh(!FlatListRefresh);
        console.log("SelectSubject, FlatListRefresh : ", FlatListRefresh);
    }

    const ShowSubjectFlatList = (Itmsection, Index) => {
        return(
            <View>
                <TouchableOpacity style={{backgroundColor: "#FFFFFF", alignItems: "center",
                            height: DEVICEHEIGHT * 0.05,}}
                            onPress={() => SelectSubject(Itmsection.id, Itmsection.section)} key={Itmsection.id}>
                    <Text style={{width: "92%", color: "#000000", fontSize: 17, marginBottom: 0}}>
                            {Itmsection.section}. </Text>
                </TouchableOpacity>
                    <View style={{backgroundColor: "#C0C0C0", width: "100%", height: 1}}></View>                        
            </View>
        );
    }
    //--------------------------------------------------
   return (
    <View style={styles.Mcontainer}>

        <View style={{padding: 10, alignItems: "center", height: DEVICEHEIGHT * 0.15}}>
            <View style={styles.Row1}>
                <View style={styles.Column1}>
                    <Text style={{fontSize: 20, fontWeight: "700"}}>Your Home work</Text>
                    <Text style={{fontSize: 20, fontWeight: "700"}}>is here!</Text>
                </View>
                    <View style={{width: DEVICEWIDTH * 0.27, flexDirection: "column", alignItems: "center"}}>
                        <Image source={require('../assets/HomeWork2.jpg')} style={{width: 100, height: 100, 
                            borderRadius: 20,}}/>
                    </View>
            </View>

        </View>
        <TouchableOpacity style={{backgroundColor: "#FFFFFF", width: '80%', height: 30,
            borderRadius: 20, flexDirection: "row", top: "5%", left: "2%", alignItems: "center"}}
            onPress={() => SubjectFilter()}>
            <Text style={{width: "88%", fontSize: 14, fontWeight: "bold", marginLeft: 10}}>{SelectedSubject}</Text>
            <FontAwesome name={chevrondownSection ? "chevron-down" : "chevron-up"}
                            size={19} color="black"/>
        </TouchableOpacity>
    {
        isLoading ? (
            <ActivityIndicator/>
        ):(
            <View style={styles.Mcontainer}>
            {
            DataS.length == 0 ? (
                <View style={{alignItems: "center", marginTop: 70}}>
                    <Text>There is no data</Text>
                </View>
            ) : (
                <View style={{top: "5%"}}>
                {/* <View style={{flexDirection: "row", height: DEVICEHEIGHT * 0.05, marginLeft: 10, marginBottom: 20,
                                    backgroundColor: "#DDD9D9", width: DEVICEWIDTH * 0.65, borderRadius: 15}}>
                  <TouchableOpacity onPress={()=> ChoosePending()}>
                    <View style={{backgroundColor: SelectPending ? "#DDA0DD" : "#DDD9D9", 
                                borderRadius: 15, width: DEVICEWIDTH * 0.265,
                                height: DEVICEHEIGHT * 0.05, justifyContent: "center", alignItems: "center"}}>
                        <Text style={{color: SelectPending ? "#FFFFFF" : "#000000", 
                                      fontWeight: SelectPending ? "bold" : "normal"}}>
                            Student</Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={()=> ChooseSubmite()}>
                    <View style={{backgroundColor: SelectSubmit ? "#DDA0DD" : "#DDD9D9", borderRadius: 15, 
                                width: DEVICEWIDTH * 0.265, height: DEVICEHEIGHT * 0.05, 
                                justifyContent: "center", alignItems: "center"}}>
                        <Text style={{color: SelectSubmit ? "#FFFFFF" : "#000000", 
                                      fontWeight: SelectSubmit ? "bold" : "normal"}}>Parents</Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={()=> ChooseEvaluate()}>
                    <View style={{backgroundColor: SelectEvaluate ? "#DDA0DD" : "#DDD9D9", borderRadius: 15, 
                                width: DEVICEWIDTH * 0.265, height: DEVICEHEIGHT * 0.05, 
                                justifyContent: "center", alignItems: "center"}}>
                        <Text style={{color: SelectEvaluate ? "#FFFFFF" : "#000000",
                                      fontWeight: SelectEvaluate ? "bold" : "normal"}}>Staff</Text>
                    </View>
                  </TouchableOpacity>

                </View> */}

                <FlatList contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}
                    data={DataS.homeworklist}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({item, index}) => ShowList(item, index)} extraData = {FlatListRefresh}
                    style={{marginBottom: 280}}
                />
            </View>
                )
        }
        </View>
        )
    }
        <FlatList contentContainerStyle={{ flexGrow: 1 }}
            showsVerticalScrollIndicator={false}
            data={Subjects} style={[styles.dropdownSection, {display: SectionLView}]}
            keyExtractor={(item, indexx) => indexx.toString()}
            renderItem={({item, indexx}) => ShowSubjectFlatList(item, indexx)}
        />

    </View>
  );
};
export default StudHomeWork;


/*        <ScrollView showsVerticalScrollIndicator={false} style={styles.SContainer}>
            {
                DataS.map((items, index) => <ShowList/>)
            }
        </ScrollView>
*/

const styles = StyleSheet.create({
    Mcontainer: {
        width: DEVICEWIDTH,
        height: DEVICEHEIGHT,
    },
    SContainer: {
        marginTop: DEVICEHEIGHT * 0.01,
        left: "2.35%",        
    },
    CardView2: {
        left: "40%",        
        elevation: 5,
        transform: [{ translateX: -(DEVICEWIDTH * 0.4) }, 
                    { translateY: -90 }],
        width: DEVICEWIDTH * 0.95,
        backgroundColor: "#FFFFFF",
        borderRadius: 15,
        marginTop: DEVICEHEIGHT * 0.12,
        marginBottom: -DEVICEHEIGHT * 0.1,
    },
    Row1: {
        flexDirection: "row",
    },
    Row2: {
        flexDirection: "row",
        marginTop: 10,
    },
    Column1: {
        flexDirection: "column",
        width: DEVICEWIDTH * 0.64,
    },
    Column2: {
        flexDirection: "column",
        width: DEVICEWIDTH * 0.93,
        alignItems: "center",
    },
    dropdownBtnStyle: {
        textAlign: "center",
        width: '75%',
        height: DEVICEHEIGHT * 0.04,
        backgroundColor: '#FFFFFF',
        borderRadius: 15,
        marginTop: DEVICEHEIGHT * 0.017,

    },
    dropdownBtnTextStyle: {
        color: '#000000',
        textAlign: "left",
        fontWeight: 'bold',
        width: 350,
    },
    DropDIcon: {
    right: 0,
    },
    dropdownSection: {
        position: 'absolute',
        backgroundColor: '#fff',
        width: '80%',
        height: "40%",
        shadowColor: '#000000',
        shadowRadius: 4,
        shadowOffset: { height: 4, width: 0 },
        shadowOpacity: 0.5,
        elevation: 3,
        top: "22%",
        left: "4%",
    },
     
});