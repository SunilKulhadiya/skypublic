import React from 'react';
import { StyleSheet, View, Text, SafeAreaView, FlatList, ActivityIndicator, Image, 
        Dimensions } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';   
import { FontAwesome } from '@expo/vector-icons';
        
const DEVICEWIDTH = Dimensions.get('window').width;
const DEVICEHEIGHT = Dimensions.get('window').height;

export default function GallerySky() {

    const[FetchData, set_FetchData] = React.useState([]);
    const [isLoading, reset_isLoading]=React.useState(true);
    const [isLoadingFlatList, reset_isLoadingFlatList]=React.useState(true);
    const [ImgUrl, setImgUrl] = React.useState([]);

    FetchPersonal = async ()=>{
        AsyncStorage.getItem('SERVERURL').then(async (value) => {
            try{
                let respons1 = await fetch(value+'api/Webservice/imagesmulti', {
                    method: 'POST', headers: {'Accept': 'application/json', 'Content-Type': 'application/json',}
                })
        
                let responseJson = await respons1.json();
                
                set_FetchData(responseJson);
                
                    reset_isLoading(false);
        
            }catch(err){
                console.error("Error-1 : ",err);
            }
        });
    }

    React.useEffect(() => {
        setTimeout(()=>{
        FetchPersonal()}, 2000);
    },[]);

    const ShowList = (Itm) => {
        setImgUrl(Itm.images);
        console.log("source : ", ImgUrl.length);
        return(
        <View style={styles.SContainer}>
            <View style={styles.CardView2}>
                <View style={{width: DEVICEWIDTH * 0.95, height: DEVICEHEIGHT * 0.05, backgroundColor: "#BAFAFF",
                                borderTopLeftRadius: 15, borderTopRightRadius: 15, justifyContent: "center"}}>
                        <Text style={{color: "#000000", marginLeft: 10, fontWeight: "bold", width: DEVICEWIDTH * 0.6}}>
                            {Itm.title}</Text>
                </View>
                <View style={{marginTop: 10}}></View>
                <FlatList contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}
                data={ImgUrl}
                keyExtractor={(item, index) => index.toString()}
                renderItem={(item) => ShowGridImg(item)}
                numColumns={3}
                />
                <View style={{marginTop: 10}}></View>
            </View>
        </View>
        );
    }
    
    const ShowGridImg = (IMG1) => {
        console.log("url : ", IMG1.item);
        return(
        <View style={{flex: 1, flexDirection: 'column', padding: 5, alignItems: 'center'}}>
            <Image source={{uri: 'http://skygroup.rootstechnology.in/school/'+IMG1.item}} style={{width: 110, height: 110, 
            borderRadius: 10,}}/>
        </View>
        );
    }


  return (
    <SafeAreaView>
        <View style={styles.Mcontainer}>
            <View style={{padding: 10, alignItems: "center", height: DEVICEHEIGHT * 0.15}}>
                <View style={styles.Column1}>
                    <View style={{alignItems: "center"}}>
                        <Image source={require('../assets/logoBn.png')} style={{width: 80, height: 80, 
                            borderRadius: 20,}}/>
                        <Text style={{color: "#1807B4", fontWeight: 'bold', fontSize: 16}}>Sky Public Hr. Sec. School</Text>
                    </View>
                </View>
            </View>

            <View>
            {
                isLoading ? (
                    <ActivityIndicator/>
                ):(
                    <View>

                            <FlatList contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}
                                data={FetchData.result}
                                keyExtractor={(item, indexx) => indexx.toString()}
                                renderItem={({item, indexx}) => ShowList(item, indexx)}
                            />

                    </View>
                )
            }
            </View>
        </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  Mcontainer: {
      width: DEVICEWIDTH,
      height: DEVICEHEIGHT,
  },
  SContainer: {
      marginTop: DEVICEHEIGHT * 0.01,
      left: "2.35%",        
  },
  CardView2: {
      left: "40%",        
      elevation: 5,
      transform: [{ translateX: -(DEVICEWIDTH * 0.4) }, 
                  { translateY: -90 }],
      backgroundColor: "#FFFFFF",
      borderRadius: 15,
      width: DEVICEWIDTH * 0.95,
      marginTop: DEVICEHEIGHT * 0.12,
      marginBottom: -DEVICEHEIGHT * 0.1,
  },
  Row1: {
      flexDirection: "row",
  },
  Row2: {
      flexDirection: "row",
      marginLeft: 10,
      marginTop: 10,
  },
  Column1: {
      flexDirection: "column",
      width: DEVICEWIDTH * 0.64,
  },
  Column2: {
      flexDirection: "column",
      width: DEVICEWIDTH,
      marginLeft: 10,
      marginTop: 35,
  },
  dropdownBtnStyle: {
      textAlign: "center",
      width: '55%',
      height: DEVICEHEIGHT * 0.04,
      backgroundColor: '#FFFFFF',
      borderRadius: 15,
      marginTop: DEVICEHEIGHT * 0.017,
      left: "1.6%",
  },
  dropdownBtnTextStyle: {
      color: '#000000',
      textAlign: "left",
      fontWeight: 'bold',
      width: 350,
  },
  DropDIcon: {
  right: 0,
  },
  dropdownBtnStyleMonth: {
    textAlign: "center",
    width: '20%',
    height: DEVICEHEIGHT * 0.04,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    left: "1.6%",
},
dropdownBtnStyleYear: {
    textAlign: "center",
    width: '30%',
    height: DEVICEHEIGHT * 0.04,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    left: "1.6%",
},

});




/*
                <FlatList contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}
                        data={ImgUrl}
                        keyExtractor={(Img1, Sindex) => Sindex.toString()}
                        renderItem={({Img1, Sindex}) => ShowGridImg(Img1, Sindex)}
                />
*/